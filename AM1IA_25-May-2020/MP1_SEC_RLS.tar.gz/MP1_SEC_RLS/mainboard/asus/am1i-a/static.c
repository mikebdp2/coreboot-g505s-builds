#include <device/device.h>
#include <device/pci.h>
#include "drivers/pc80/tpm/chip.h"
#include "northbridge/amd/agesa/family16kb/chip.h"
#include "southbridge/amd/agesa/hudson/chip.h"
#include "superio/ite/it8623e/chip.h"

#if !DEVTREE_EARLY
__attribute__((weak)) struct chip_operations mainboard_ops = {};
__attribute__((weak)) struct chip_operations cpu_amd_agesa_family16kb_ops = {};
__attribute__((weak)) struct chip_operations drivers_pc80_tpm_ops = {};
__attribute__((weak)) struct chip_operations northbridge_amd_agesa_family16kb_ops = {};
__attribute__((weak)) struct chip_operations northbridge_amd_agesa_family16kb_root_complex_ops = {};
__attribute__((weak)) struct chip_operations southbridge_amd_agesa_hudson_ops = {};
__attribute__((weak)) struct chip_operations superio_ite_it8623e_ops = {};
#endif

#define STORAGE static __unused DEVTREE_CONST

STORAGE struct drivers_pc80_tpm_config drivers_pc80_tpm_info_1 = {};

STORAGE struct northbridge_amd_agesa_family16kb_config northbridge_amd_agesa_family16kb_info_1 = {
	.spdAddrLookup = 
			{
				{ {0xA0, 0xA2} },
			},
};

STORAGE struct northbridge_amd_agesa_family16kb_config northbridge_amd_agesa_family16kb_info_2 = {};

STORAGE struct southbridge_amd_agesa_hudson_config southbridge_amd_agesa_hudson_info_1 = {};

STORAGE struct superio_ite_it8623e_config superio_ite_it8623e_info_1 = {};


/* pass 0 */
STORAGE struct bus dev_root_links[];
STORAGE struct device _dev0;
STORAGE struct bus _dev0_links[];
STORAGE struct device _dev1;
STORAGE struct bus _dev1_links[];
STORAGE struct device _dev2;
STORAGE struct device _dev3;
STORAGE struct device _dev4;
STORAGE struct device _dev5;
STORAGE struct device _dev6;
STORAGE struct device _dev7;
STORAGE struct device _dev8;
STORAGE struct device _dev9;
STORAGE struct device _dev10;
STORAGE struct device _dev11;
STORAGE struct device _dev12;
STORAGE struct device _dev13;
STORAGE struct device _dev14;
STORAGE struct device _dev15;
STORAGE struct device _dev16;
STORAGE struct device _dev17;
STORAGE struct device _dev18;
STORAGE struct device _dev19;
STORAGE struct device _dev20;
STORAGE struct bus _dev20_links[];
STORAGE struct device _dev21;
STORAGE struct device _dev22;
STORAGE struct device _dev23;
STORAGE struct device _dev24;
STORAGE struct device _dev25;
STORAGE struct device _dev26;
STORAGE struct device _dev27;
STORAGE struct device _dev28;
STORAGE struct device _dev29;
STORAGE struct device _dev30;
STORAGE struct device _dev31;
STORAGE struct resource _dev31_res[];
STORAGE struct device _dev32;
STORAGE struct resource _dev32_res[];
STORAGE struct device _dev33;
STORAGE struct resource _dev33_res[];
STORAGE struct device _dev34;
STORAGE struct resource _dev34_res[];
STORAGE struct device _dev35;
STORAGE struct resource _dev35_res[];
STORAGE struct device _dev36;
STORAGE struct resource _dev36_res[];
STORAGE struct device _dev37;
STORAGE struct resource _dev37_res[];
STORAGE struct device _dev38;
DEVTREE_CONST struct device * DEVTREE_CONST last_dev = &_dev38;

/* pass 1 */
DEVTREE_CONST struct device dev_root = {
#if !DEVTREE_EARLY
	.ops = &default_dev_ops_root,
#endif
	.bus = &dev_root_links[0],
	.path = { .type = DEVICE_PATH_ROOT },
	.enabled = 1,
	.hidden = 0,
	.mandatory = 0,
	.on_mainboard = 1,
	.link_list = &dev_root_links[0],
	.sibling = NULL,
#if !DEVTREE_EARLY
	.chip_ops = &mainboard_ops,
	.name = mainboard_name,
#endif
	.next=&_dev0,
};
STORAGE struct bus dev_root_links[] = {
		[0] = {
			.link_num = 0,
			.dev = &dev_root,
			.children = &_dev0,
			.next = NULL,
		},
	};
STORAGE struct device _dev0 = {
#if !DEVTREE_EARLY
	.ops = NULL,
#endif
	.bus = &dev_root_links[0],
	.path = {.type=DEVICE_PATH_CPU_CLUSTER,{.cpu_cluster={ .cluster = 0x0 }}},
	.enabled = 1,
	.hidden = 0,
	.mandatory = 0,
	.on_mainboard = 1,
	.link_list = &_dev0_links[0],
	.sibling = &_dev1,
#if !DEVTREE_EARLY
	.chip_ops = &northbridge_amd_agesa_family16kb_root_complex_ops,
#endif
	.next=&_dev1,
};
STORAGE struct bus _dev0_links[] = {
		[0] = {
			.link_num = 0,
			.dev = &_dev0,
			.children = &_dev2,
			.next = NULL,
		},
	};
STORAGE struct device _dev1 = {
#if !DEVTREE_EARLY
	.ops = NULL,
#endif
	.bus = &dev_root_links[0],
	.path = {.type=DEVICE_PATH_DOMAIN,{.domain={ .domain = 0x0 }}},
	.enabled = 1,
	.hidden = 0,
	.mandatory = 0,
	.on_mainboard = 1,
	.subsystem_vendor = 0x1043,
	.subsystem_device = 0x8623,
	.link_list = &_dev1_links[0],
	.sibling = NULL,
#if !DEVTREE_EARLY
	.chip_ops = &northbridge_amd_agesa_family16kb_root_complex_ops,
#endif
	.next=&_dev2,
};
STORAGE struct bus _dev1_links[] = {
		[0] = {
			.link_num = 0,
			.dev = &_dev1,
			.children = &_dev3,
			.next = NULL,
		},
	};
STORAGE struct device _dev2 = {
#if !DEVTREE_EARLY
	.ops = NULL,
#endif
	.bus = &_dev0_links[0],
	.path = {.type=DEVICE_PATH_APIC,{.apic={ .apic_id = 0x0 }}},
	.enabled = 1,
	.hidden = 0,
	.mandatory = 0,
	.on_mainboard = 1,
	.link_list = NULL,
	.sibling = NULL,
#if !DEVTREE_EARLY
	.chip_ops = &cpu_amd_agesa_family16kb_ops,
#endif
	.next=&_dev3,
};
STORAGE struct device _dev3 = {
#if !DEVTREE_EARLY
	.ops = NULL,
#endif
	.bus = &_dev1_links[0],
	.path = {.type=DEVICE_PATH_PCI,{.pci={ .devfn = PCI_DEVFN(0x0,0)}}},
	.enabled = 1,
	.hidden = 0,
	.mandatory = 0,
	.on_mainboard = 1,
	.subsystem_vendor = 0x1043,
	.subsystem_device = 0x8623,
	.link_list = NULL,
	.sibling = &_dev4,
#if !DEVTREE_EARLY
	.chip_ops = &northbridge_amd_agesa_family16kb_ops,
#endif
	.chip_info = &northbridge_amd_agesa_family16kb_info_2,
	.next=&_dev4,
};
STORAGE struct device _dev4 = {
#if !DEVTREE_EARLY
	.ops = NULL,
#endif
	.bus = &_dev1_links[0],
	.path = {.type=DEVICE_PATH_PCI,{.pci={ .devfn = PCI_DEVFN(0x1,0)}}},
	.enabled = 1,
	.hidden = 0,
	.mandatory = 0,
	.on_mainboard = 1,
	.subsystem_vendor = 0x1043,
	.subsystem_device = 0x8623,
	.link_list = NULL,
	.sibling = &_dev5,
#if !DEVTREE_EARLY
	.chip_ops = &northbridge_amd_agesa_family16kb_ops,
#endif
	.chip_info = &northbridge_amd_agesa_family16kb_info_2,
	.next=&_dev5,
};
STORAGE struct device _dev5 = {
#if !DEVTREE_EARLY
	.ops = NULL,
#endif
	.bus = &_dev1_links[0],
	.path = {.type=DEVICE_PATH_PCI,{.pci={ .devfn = PCI_DEVFN(0x1,1)}}},
	.enabled = 1,
	.hidden = 0,
	.mandatory = 0,
	.on_mainboard = 1,
	.subsystem_vendor = 0x1043,
	.subsystem_device = 0x8623,
	.link_list = NULL,
	.sibling = &_dev6,
#if !DEVTREE_EARLY
	.chip_ops = &northbridge_amd_agesa_family16kb_ops,
#endif
	.chip_info = &northbridge_amd_agesa_family16kb_info_2,
	.next=&_dev6,
};
STORAGE struct device _dev6 = {
#if !DEVTREE_EARLY
	.ops = NULL,
#endif
	.bus = &_dev1_links[0],
	.path = {.type=DEVICE_PATH_PCI,{.pci={ .devfn = PCI_DEVFN(0x2,0)}}},
	.enabled = 1,
	.hidden = 0,
	.mandatory = 0,
	.on_mainboard = 1,
	.subsystem_vendor = 0x1043,
	.subsystem_device = 0x8623,
	.link_list = NULL,
	.sibling = &_dev7,
#if !DEVTREE_EARLY
	.chip_ops = &northbridge_amd_agesa_family16kb_ops,
#endif
	.chip_info = &northbridge_amd_agesa_family16kb_info_2,
	.next=&_dev7,
};
STORAGE struct device _dev7 = {
#if !DEVTREE_EARLY
	.ops = NULL,
#endif
	.bus = &_dev1_links[0],
	.path = {.type=DEVICE_PATH_PCI,{.pci={ .devfn = PCI_DEVFN(0x2,1)}}},
	.enabled = 1,
	.hidden = 0,
	.mandatory = 0,
	.on_mainboard = 1,
	.subsystem_vendor = 0x1043,
	.subsystem_device = 0x8623,
	.link_list = NULL,
	.sibling = &_dev8,
#if !DEVTREE_EARLY
	.chip_ops = &northbridge_amd_agesa_family16kb_ops,
#endif
	.chip_info = &northbridge_amd_agesa_family16kb_info_2,
	.next=&_dev8,
};
STORAGE struct device _dev8 = {
#if !DEVTREE_EARLY
	.ops = NULL,
#endif
	.bus = &_dev1_links[0],
	.path = {.type=DEVICE_PATH_PCI,{.pci={ .devfn = PCI_DEVFN(0x2,2)}}},
	.enabled = 0,
	.hidden = 0,
	.mandatory = 0,
	.on_mainboard = 1,
	.subsystem_vendor = 0x1043,
	.subsystem_device = 0x8623,
	.link_list = NULL,
	.sibling = &_dev9,
#if !DEVTREE_EARLY
	.chip_ops = &northbridge_amd_agesa_family16kb_ops,
#endif
	.chip_info = &northbridge_amd_agesa_family16kb_info_2,
	.next=&_dev9,
};
STORAGE struct device _dev9 = {
#if !DEVTREE_EARLY
	.ops = NULL,
#endif
	.bus = &_dev1_links[0],
	.path = {.type=DEVICE_PATH_PCI,{.pci={ .devfn = PCI_DEVFN(0x2,3)}}},
	.enabled = 0,
	.hidden = 0,
	.mandatory = 0,
	.on_mainboard = 1,
	.subsystem_vendor = 0x1043,
	.subsystem_device = 0x8623,
	.link_list = NULL,
	.sibling = &_dev10,
#if !DEVTREE_EARLY
	.chip_ops = &northbridge_amd_agesa_family16kb_ops,
#endif
	.chip_info = &northbridge_amd_agesa_family16kb_info_2,
	.next=&_dev10,
};
STORAGE struct device _dev10 = {
#if !DEVTREE_EARLY
	.ops = NULL,
#endif
	.bus = &_dev1_links[0],
	.path = {.type=DEVICE_PATH_PCI,{.pci={ .devfn = PCI_DEVFN(0x2,4)}}},
	.enabled = 0,
	.hidden = 0,
	.mandatory = 0,
	.on_mainboard = 1,
	.subsystem_vendor = 0x1043,
	.subsystem_device = 0x8623,
	.link_list = NULL,
	.sibling = &_dev11,
#if !DEVTREE_EARLY
	.chip_ops = &northbridge_amd_agesa_family16kb_ops,
#endif
	.chip_info = &northbridge_amd_agesa_family16kb_info_2,
	.next=&_dev11,
};
STORAGE struct device _dev11 = {
#if !DEVTREE_EARLY
	.ops = NULL,
#endif
	.bus = &_dev1_links[0],
	.path = {.type=DEVICE_PATH_PCI,{.pci={ .devfn = PCI_DEVFN(0x2,5)}}},
	.enabled = 1,
	.hidden = 0,
	.mandatory = 0,
	.on_mainboard = 1,
	.subsystem_vendor = 0x1043,
	.subsystem_device = 0x8623,
	.link_list = NULL,
	.sibling = &_dev12,
#if !DEVTREE_EARLY
	.chip_ops = &northbridge_amd_agesa_family16kb_ops,
#endif
	.chip_info = &northbridge_amd_agesa_family16kb_info_2,
	.next=&_dev12,
};
STORAGE struct device _dev12 = {
#if !DEVTREE_EARLY
	.ops = NULL,
#endif
	.bus = &_dev1_links[0],
	.path = {.type=DEVICE_PATH_PCI,{.pci={ .devfn = PCI_DEVFN(0x10,0)}}},
	.enabled = 1,
	.hidden = 0,
	.mandatory = 0,
	.on_mainboard = 1,
	.subsystem_vendor = 0x1043,
	.subsystem_device = 0x8623,
	.link_list = NULL,
	.sibling = &_dev13,
#if !DEVTREE_EARLY
	.chip_ops = &southbridge_amd_agesa_hudson_ops,
#endif
	.chip_info = &southbridge_amd_agesa_hudson_info_1,
	.next=&_dev13,
};
STORAGE struct device _dev13 = {
#if !DEVTREE_EARLY
	.ops = NULL,
#endif
	.bus = &_dev1_links[0],
	.path = {.type=DEVICE_PATH_PCI,{.pci={ .devfn = PCI_DEVFN(0x11,0)}}},
	.enabled = 1,
	.hidden = 0,
	.mandatory = 0,
	.on_mainboard = 1,
	.subsystem_vendor = 0x1043,
	.subsystem_device = 0x8623,
	.link_list = NULL,
	.sibling = &_dev14,
#if !DEVTREE_EARLY
	.chip_ops = &southbridge_amd_agesa_hudson_ops,
#endif
	.chip_info = &southbridge_amd_agesa_hudson_info_1,
	.next=&_dev14,
};
STORAGE struct device _dev14 = {
#if !DEVTREE_EARLY
	.ops = NULL,
#endif
	.bus = &_dev1_links[0],
	.path = {.type=DEVICE_PATH_PCI,{.pci={ .devfn = PCI_DEVFN(0x12,0)}}},
	.enabled = 1,
	.hidden = 0,
	.mandatory = 0,
	.on_mainboard = 1,
	.subsystem_vendor = 0x1043,
	.subsystem_device = 0x8623,
	.link_list = NULL,
	.sibling = &_dev15,
#if !DEVTREE_EARLY
	.chip_ops = &southbridge_amd_agesa_hudson_ops,
#endif
	.chip_info = &southbridge_amd_agesa_hudson_info_1,
	.next=&_dev15,
};
STORAGE struct device _dev15 = {
#if !DEVTREE_EARLY
	.ops = NULL,
#endif
	.bus = &_dev1_links[0],
	.path = {.type=DEVICE_PATH_PCI,{.pci={ .devfn = PCI_DEVFN(0x12,2)}}},
	.enabled = 1,
	.hidden = 0,
	.mandatory = 0,
	.on_mainboard = 1,
	.subsystem_vendor = 0x1043,
	.subsystem_device = 0x8623,
	.link_list = NULL,
	.sibling = &_dev16,
#if !DEVTREE_EARLY
	.chip_ops = &southbridge_amd_agesa_hudson_ops,
#endif
	.chip_info = &southbridge_amd_agesa_hudson_info_1,
	.next=&_dev16,
};
STORAGE struct device _dev16 = {
#if !DEVTREE_EARLY
	.ops = NULL,
#endif
	.bus = &_dev1_links[0],
	.path = {.type=DEVICE_PATH_PCI,{.pci={ .devfn = PCI_DEVFN(0x13,0)}}},
	.enabled = 1,
	.hidden = 0,
	.mandatory = 0,
	.on_mainboard = 1,
	.subsystem_vendor = 0x1043,
	.subsystem_device = 0x8623,
	.link_list = NULL,
	.sibling = &_dev17,
#if !DEVTREE_EARLY
	.chip_ops = &southbridge_amd_agesa_hudson_ops,
#endif
	.chip_info = &southbridge_amd_agesa_hudson_info_1,
	.next=&_dev17,
};
STORAGE struct device _dev17 = {
#if !DEVTREE_EARLY
	.ops = NULL,
#endif
	.bus = &_dev1_links[0],
	.path = {.type=DEVICE_PATH_PCI,{.pci={ .devfn = PCI_DEVFN(0x13,2)}}},
	.enabled = 1,
	.hidden = 0,
	.mandatory = 0,
	.on_mainboard = 1,
	.subsystem_vendor = 0x1043,
	.subsystem_device = 0x8623,
	.link_list = NULL,
	.sibling = &_dev18,
#if !DEVTREE_EARLY
	.chip_ops = &southbridge_amd_agesa_hudson_ops,
#endif
	.chip_info = &southbridge_amd_agesa_hudson_info_1,
	.next=&_dev18,
};
STORAGE struct device _dev18 = {
#if !DEVTREE_EARLY
	.ops = NULL,
#endif
	.bus = &_dev1_links[0],
	.path = {.type=DEVICE_PATH_PCI,{.pci={ .devfn = PCI_DEVFN(0x14,0)}}},
	.enabled = 1,
	.hidden = 0,
	.mandatory = 0,
	.on_mainboard = 1,
	.subsystem_vendor = 0x1043,
	.subsystem_device = 0x8623,
	.link_list = NULL,
	.sibling = &_dev19,
#if !DEVTREE_EARLY
	.chip_ops = &southbridge_amd_agesa_hudson_ops,
#endif
	.chip_info = &southbridge_amd_agesa_hudson_info_1,
	.next=&_dev19,
};
STORAGE struct device _dev19 = {
#if !DEVTREE_EARLY
	.ops = NULL,
#endif
	.bus = &_dev1_links[0],
	.path = {.type=DEVICE_PATH_PCI,{.pci={ .devfn = PCI_DEVFN(0x14,2)}}},
	.enabled = 1,
	.hidden = 0,
	.mandatory = 0,
	.on_mainboard = 1,
	.subsystem_vendor = 0x1043,
	.subsystem_device = 0x8623,
	.link_list = NULL,
	.sibling = &_dev20,
#if !DEVTREE_EARLY
	.chip_ops = &southbridge_amd_agesa_hudson_ops,
#endif
	.chip_info = &southbridge_amd_agesa_hudson_info_1,
	.next=&_dev20,
};
STORAGE struct device _dev20 = {
#if !DEVTREE_EARLY
	.ops = NULL,
#endif
	.bus = &_dev1_links[0],
	.path = {.type=DEVICE_PATH_PCI,{.pci={ .devfn = PCI_DEVFN(0x14,3)}}},
	.enabled = 1,
	.hidden = 0,
	.mandatory = 0,
	.on_mainboard = 1,
	.subsystem_vendor = 0x1043,
	.subsystem_device = 0x8623,
	.link_list = &_dev20_links[0],
	.sibling = &_dev21,
#if !DEVTREE_EARLY
	.chip_ops = &southbridge_amd_agesa_hudson_ops,
#endif
	.chip_info = &southbridge_amd_agesa_hudson_info_1,
	.next=&_dev21,
};
STORAGE struct bus _dev20_links[] = {
		[0] = {
			.link_num = 0,
			.dev = &_dev20,
			.children = &_dev30,
			.next = NULL,
		},
	};
STORAGE struct device _dev21 = {
#if !DEVTREE_EARLY
	.ops = NULL,
#endif
	.bus = &_dev1_links[0],
	.path = {.type=DEVICE_PATH_PCI,{.pci={ .devfn = PCI_DEVFN(0x14,7)}}},
	.enabled = 0,
	.hidden = 0,
	.mandatory = 0,
	.on_mainboard = 1,
	.subsystem_vendor = 0x1043,
	.subsystem_device = 0x8623,
	.link_list = NULL,
	.sibling = &_dev22,
#if !DEVTREE_EARLY
	.chip_ops = &southbridge_amd_agesa_hudson_ops,
#endif
	.chip_info = &southbridge_amd_agesa_hudson_info_1,
	.next=&_dev22,
};
STORAGE struct device _dev22 = {
#if !DEVTREE_EARLY
	.ops = NULL,
#endif
	.bus = &_dev1_links[0],
	.path = {.type=DEVICE_PATH_PCI,{.pci={ .devfn = PCI_DEVFN(0x16,0)}}},
	.enabled = 1,
	.hidden = 0,
	.mandatory = 0,
	.on_mainboard = 1,
	.subsystem_vendor = 0x1043,
	.subsystem_device = 0x8623,
	.link_list = NULL,
	.sibling = &_dev23,
#if !DEVTREE_EARLY
	.chip_ops = &southbridge_amd_agesa_hudson_ops,
#endif
	.chip_info = &southbridge_amd_agesa_hudson_info_1,
	.next=&_dev23,
};
STORAGE struct device _dev23 = {
#if !DEVTREE_EARLY
	.ops = NULL,
#endif
	.bus = &_dev1_links[0],
	.path = {.type=DEVICE_PATH_PCI,{.pci={ .devfn = PCI_DEVFN(0x16,2)}}},
	.enabled = 1,
	.hidden = 0,
	.mandatory = 0,
	.on_mainboard = 1,
	.subsystem_vendor = 0x1043,
	.subsystem_device = 0x8623,
	.link_list = NULL,
	.sibling = &_dev24,
#if !DEVTREE_EARLY
	.chip_ops = &southbridge_amd_agesa_hudson_ops,
#endif
	.chip_info = &southbridge_amd_agesa_hudson_info_1,
	.next=&_dev24,
};
STORAGE struct device _dev24 = {
#if !DEVTREE_EARLY
	.ops = NULL,
#endif
	.bus = &_dev1_links[0],
	.path = {.type=DEVICE_PATH_PCI,{.pci={ .devfn = PCI_DEVFN(0x18,0)}}},
	.enabled = 1,
	.hidden = 0,
	.mandatory = 0,
	.on_mainboard = 1,
	.subsystem_vendor = 0x1043,
	.subsystem_device = 0x8623,
	.link_list = NULL,
	.sibling = &_dev25,
#if !DEVTREE_EARLY
	.chip_ops = &northbridge_amd_agesa_family16kb_ops,
#endif
	.chip_info = &northbridge_amd_agesa_family16kb_info_1,
	.next=&_dev25,
};
STORAGE struct device _dev25 = {
#if !DEVTREE_EARLY
	.ops = NULL,
#endif
	.bus = &_dev1_links[0],
	.path = {.type=DEVICE_PATH_PCI,{.pci={ .devfn = PCI_DEVFN(0x18,1)}}},
	.enabled = 1,
	.hidden = 0,
	.mandatory = 0,
	.on_mainboard = 1,
	.subsystem_vendor = 0x1043,
	.subsystem_device = 0x8623,
	.link_list = NULL,
	.sibling = &_dev26,
#if !DEVTREE_EARLY
	.chip_ops = &northbridge_amd_agesa_family16kb_ops,
#endif
	.chip_info = &northbridge_amd_agesa_family16kb_info_1,
	.next=&_dev26,
};
STORAGE struct device _dev26 = {
#if !DEVTREE_EARLY
	.ops = NULL,
#endif
	.bus = &_dev1_links[0],
	.path = {.type=DEVICE_PATH_PCI,{.pci={ .devfn = PCI_DEVFN(0x18,2)}}},
	.enabled = 1,
	.hidden = 0,
	.mandatory = 0,
	.on_mainboard = 1,
	.subsystem_vendor = 0x1043,
	.subsystem_device = 0x8623,
	.link_list = NULL,
	.sibling = &_dev27,
#if !DEVTREE_EARLY
	.chip_ops = &northbridge_amd_agesa_family16kb_ops,
#endif
	.chip_info = &northbridge_amd_agesa_family16kb_info_1,
	.next=&_dev27,
};
STORAGE struct device _dev27 = {
#if !DEVTREE_EARLY
	.ops = NULL,
#endif
	.bus = &_dev1_links[0],
	.path = {.type=DEVICE_PATH_PCI,{.pci={ .devfn = PCI_DEVFN(0x18,3)}}},
	.enabled = 1,
	.hidden = 0,
	.mandatory = 0,
	.on_mainboard = 1,
	.subsystem_vendor = 0x1043,
	.subsystem_device = 0x8623,
	.link_list = NULL,
	.sibling = &_dev28,
#if !DEVTREE_EARLY
	.chip_ops = &northbridge_amd_agesa_family16kb_ops,
#endif
	.chip_info = &northbridge_amd_agesa_family16kb_info_1,
	.next=&_dev28,
};
STORAGE struct device _dev28 = {
#if !DEVTREE_EARLY
	.ops = NULL,
#endif
	.bus = &_dev1_links[0],
	.path = {.type=DEVICE_PATH_PCI,{.pci={ .devfn = PCI_DEVFN(0x18,4)}}},
	.enabled = 1,
	.hidden = 0,
	.mandatory = 0,
	.on_mainboard = 1,
	.subsystem_vendor = 0x1043,
	.subsystem_device = 0x8623,
	.link_list = NULL,
	.sibling = &_dev29,
#if !DEVTREE_EARLY
	.chip_ops = &northbridge_amd_agesa_family16kb_ops,
#endif
	.chip_info = &northbridge_amd_agesa_family16kb_info_1,
	.next=&_dev29,
};
STORAGE struct device _dev29 = {
#if !DEVTREE_EARLY
	.ops = NULL,
#endif
	.bus = &_dev1_links[0],
	.path = {.type=DEVICE_PATH_PCI,{.pci={ .devfn = PCI_DEVFN(0x18,5)}}},
	.enabled = 1,
	.hidden = 0,
	.mandatory = 0,
	.on_mainboard = 1,
	.subsystem_vendor = 0x1043,
	.subsystem_device = 0x8623,
	.link_list = NULL,
	.sibling = NULL,
#if !DEVTREE_EARLY
	.chip_ops = &northbridge_amd_agesa_family16kb_ops,
#endif
	.chip_info = &northbridge_amd_agesa_family16kb_info_1,
	.next=&_dev30,
};
STORAGE struct device _dev30 = {
#if !DEVTREE_EARLY
	.ops = NULL,
#endif
	.bus = &_dev20_links[0],
	.path = {.type=DEVICE_PATH_PNP,{.pnp={ .port = 0x2e, .device = 0x0 }}},
	.enabled = 0,
	.hidden = 0,
	.mandatory = 0,
	.on_mainboard = 1,
	.subsystem_vendor = 0x1043,
	.subsystem_device = 0x8623,
	.link_list = NULL,
	.sibling = &_dev31,
#if !DEVTREE_EARLY
	.chip_ops = &superio_ite_it8623e_ops,
#endif
	.chip_info = &superio_ite_it8623e_info_1,
	.next=&_dev31,
};
STORAGE struct device _dev31 = {
#if !DEVTREE_EARLY
	.ops = NULL,
#endif
	.bus = &_dev20_links[0],
	.path = {.type=DEVICE_PATH_PNP,{.pnp={ .port = 0x2e, .device = 0x1 }}},
	.enabled = 1,
	.hidden = 0,
	.mandatory = 0,
	.on_mainboard = 1,
	.subsystem_vendor = 0x1043,
	.subsystem_device = 0x8623,
	.resource_list = &_dev31_res[0],
	.link_list = NULL,
	.sibling = &_dev32,
#if !DEVTREE_EARLY
	.chip_ops = &superio_ite_it8623e_ops,
#endif
	.chip_info = &superio_ite_it8623e_info_1,
	.next=&_dev32,
};
STORAGE struct resource _dev31_res[] = {
		{ .flags=IORESOURCE_FIXED | IORESOURCE_ASSIGNED | IORESOURCE_IO, .index=0x60, .base=0x3f8,.next=&_dev31_res[1]},
		{ .flags=IORESOURCE_FIXED | IORESOURCE_ASSIGNED | IORESOURCE_IRQ, .index=0x70, .base=0x4,.next=NULL },
	 };
STORAGE struct device _dev32 = {
#if !DEVTREE_EARLY
	.ops = NULL,
#endif
	.bus = &_dev20_links[0],
	.path = {.type=DEVICE_PATH_PNP,{.pnp={ .port = 0x2e, .device = 0x2 }}},
	.enabled = 1,
	.hidden = 0,
	.mandatory = 0,
	.on_mainboard = 1,
	.subsystem_vendor = 0x1043,
	.subsystem_device = 0x8623,
	.resource_list = &_dev32_res[0],
	.link_list = NULL,
	.sibling = &_dev33,
#if !DEVTREE_EARLY
	.chip_ops = &superio_ite_it8623e_ops,
#endif
	.chip_info = &superio_ite_it8623e_info_1,
	.next=&_dev33,
};
STORAGE struct resource _dev32_res[] = {
		{ .flags=IORESOURCE_FIXED | IORESOURCE_ASSIGNED | IORESOURCE_IO, .index=0x60, .base=0x2f8,.next=&_dev32_res[1]},
		{ .flags=IORESOURCE_FIXED | IORESOURCE_ASSIGNED | IORESOURCE_IRQ, .index=0x70, .base=0x3,.next=NULL },
	 };
STORAGE struct device _dev33 = {
#if !DEVTREE_EARLY
	.ops = NULL,
#endif
	.bus = &_dev20_links[0],
	.path = {.type=DEVICE_PATH_PNP,{.pnp={ .port = 0x2e, .device = 0x3 }}},
	.enabled = 1,
	.hidden = 0,
	.mandatory = 0,
	.on_mainboard = 1,
	.subsystem_vendor = 0x1043,
	.subsystem_device = 0x8623,
	.resource_list = &_dev33_res[0],
	.link_list = NULL,
	.sibling = &_dev34,
#if !DEVTREE_EARLY
	.chip_ops = &superio_ite_it8623e_ops,
#endif
	.chip_info = &superio_ite_it8623e_info_1,
	.next=&_dev34,
};
STORAGE struct resource _dev33_res[] = {
		{ .flags=IORESOURCE_FIXED | IORESOURCE_ASSIGNED | IORESOURCE_IO, .index=0x60, .base=0x378,.next=&_dev33_res[1]},
		{ .flags=IORESOURCE_FIXED | IORESOURCE_ASSIGNED | IORESOURCE_IO, .index=0x62, .base=0x778,.next=&_dev33_res[2]},
		{ .flags=IORESOURCE_FIXED | IORESOURCE_ASSIGNED | IORESOURCE_IRQ, .index=0x70, .base=0x5,.next=&_dev33_res[3]},
		{ .flags=IORESOURCE_FIXED | IORESOURCE_ASSIGNED | IORESOURCE_DRQ, .index=0x74, .base=0x3,.next=NULL },
	 };
STORAGE struct device _dev34 = {
#if !DEVTREE_EARLY
	.ops = NULL,
#endif
	.bus = &_dev20_links[0],
	.path = {.type=DEVICE_PATH_PNP,{.pnp={ .port = 0x2e, .device = 0x4 }}},
	.enabled = 1,
	.hidden = 0,
	.mandatory = 0,
	.on_mainboard = 1,
	.subsystem_vendor = 0x1043,
	.subsystem_device = 0x8623,
	.resource_list = &_dev34_res[0],
	.link_list = NULL,
	.sibling = &_dev35,
#if !DEVTREE_EARLY
	.chip_ops = &superio_ite_it8623e_ops,
#endif
	.chip_info = &superio_ite_it8623e_info_1,
	.next=&_dev35,
};
STORAGE struct resource _dev34_res[] = {
		{ .flags=IORESOURCE_FIXED | IORESOURCE_ASSIGNED | IORESOURCE_IO, .index=0x60, .base=0x290,.next=&_dev34_res[1]},
		{ .flags=IORESOURCE_FIXED | IORESOURCE_ASSIGNED | IORESOURCE_IO, .index=0x62, .base=0x230,.next=NULL },
	 };
STORAGE struct device _dev35 = {
#if !DEVTREE_EARLY
	.ops = NULL,
#endif
	.bus = &_dev20_links[0],
	.path = {.type=DEVICE_PATH_PNP,{.pnp={ .port = 0x2e, .device = 0x5 }}},
	.enabled = 1,
	.hidden = 0,
	.mandatory = 0,
	.on_mainboard = 1,
	.subsystem_vendor = 0x1043,
	.subsystem_device = 0x8623,
	.resource_list = &_dev35_res[0],
	.link_list = NULL,
	.sibling = &_dev36,
#if !DEVTREE_EARLY
	.chip_ops = &superio_ite_it8623e_ops,
#endif
	.chip_info = &superio_ite_it8623e_info_1,
	.next=&_dev36,
};
STORAGE struct resource _dev35_res[] = {
		{ .flags=IORESOURCE_FIXED | IORESOURCE_ASSIGNED | IORESOURCE_IO, .index=0x60, .base=0x60,.next=&_dev35_res[1]},
		{ .flags=IORESOURCE_FIXED | IORESOURCE_ASSIGNED | IORESOURCE_IO, .index=0x62, .base=0x64,.next=&_dev35_res[2]},
		{ .flags=IORESOURCE_FIXED | IORESOURCE_ASSIGNED | IORESOURCE_IRQ, .index=0x70, .base=0x1,.next=NULL },
	 };
STORAGE struct device _dev36 = {
#if !DEVTREE_EARLY
	.ops = NULL,
#endif
	.bus = &_dev20_links[0],
	.path = {.type=DEVICE_PATH_PNP,{.pnp={ .port = 0x2e, .device = 0x6 }}},
	.enabled = 1,
	.hidden = 0,
	.mandatory = 0,
	.on_mainboard = 1,
	.subsystem_vendor = 0x1043,
	.subsystem_device = 0x8623,
	.resource_list = &_dev36_res[0],
	.link_list = NULL,
	.sibling = &_dev37,
#if !DEVTREE_EARLY
	.chip_ops = &superio_ite_it8623e_ops,
#endif
	.chip_info = &superio_ite_it8623e_info_1,
	.next=&_dev37,
};
STORAGE struct resource _dev36_res[] = {
		{ .flags=IORESOURCE_FIXED | IORESOURCE_ASSIGNED | IORESOURCE_IRQ, .index=0x70, .base=0xc,.next=NULL },
	 };
STORAGE struct device _dev37 = {
#if !DEVTREE_EARLY
	.ops = NULL,
#endif
	.bus = &_dev20_links[0],
	.path = {.type=DEVICE_PATH_PNP,{.pnp={ .port = 0x2e, .device = 0x7 }}},
	.enabled = 1,
	.hidden = 0,
	.mandatory = 0,
	.on_mainboard = 1,
	.subsystem_vendor = 0x1043,
	.subsystem_device = 0x8623,
	.resource_list = &_dev37_res[0],
	.link_list = NULL,
	.sibling = &_dev38,
#if !DEVTREE_EARLY
	.chip_ops = &superio_ite_it8623e_ops,
#endif
	.chip_info = &superio_ite_it8623e_info_1,
	.next=&_dev38,
};
STORAGE struct resource _dev37_res[] = {
		{ .flags=IORESOURCE_FIXED | IORESOURCE_ASSIGNED | IORESOURCE_IO, .index=0x60, .base=0x320,.next=&_dev37_res[1]},
		{ .flags=IORESOURCE_FIXED | IORESOURCE_ASSIGNED | IORESOURCE_IO, .index=0x62, .base=0x300,.next=&_dev37_res[2]},
		{ .flags=IORESOURCE_FIXED | IORESOURCE_ASSIGNED | IORESOURCE_IO, .index=0x64, .base=0x321,.next=NULL },
	 };
STORAGE struct device _dev38 = {
#if !DEVTREE_EARLY
	.ops = NULL,
#endif
	.bus = &_dev20_links[0],
	.path = {.type=DEVICE_PATH_PNP,{.pnp={ .port = 0x4e, .device = 0x0 }}},
	.enabled = 1,
	.hidden = 0,
	.mandatory = 0,
	.on_mainboard = 1,
	.subsystem_vendor = 0x1043,
	.subsystem_device = 0x8623,
	.link_list = NULL,
	.sibling = NULL,
#if !DEVTREE_EARLY
	.chip_ops = &drivers_pc80_tpm_ops,
#endif
	.chip_info = &drivers_pc80_tpm_info_1,
};

/* expose_device_names */
DEVTREE_CONST struct device *DEVTREE_CONST __pci_0_00_0 = &_dev3;
DEVTREE_CONST struct device *DEVTREE_CONST __pci_0_01_0 = &_dev4;
DEVTREE_CONST struct device *DEVTREE_CONST __pci_0_01_1 = &_dev5;
DEVTREE_CONST struct device *DEVTREE_CONST __pci_0_02_0 = &_dev6;
DEVTREE_CONST struct device *DEVTREE_CONST __pci_0_02_1 = &_dev7;
DEVTREE_CONST struct device *DEVTREE_CONST __pci_0_02_2 = &_dev8;
DEVTREE_CONST struct device *DEVTREE_CONST __pci_0_02_3 = &_dev9;
DEVTREE_CONST struct device *DEVTREE_CONST __pci_0_02_4 = &_dev10;
DEVTREE_CONST struct device *DEVTREE_CONST __pci_0_02_5 = &_dev11;
DEVTREE_CONST struct device *DEVTREE_CONST __pci_0_10_0 = &_dev12;
DEVTREE_CONST struct device *DEVTREE_CONST __pci_0_11_0 = &_dev13;
DEVTREE_CONST struct device *DEVTREE_CONST __pci_0_12_0 = &_dev14;
DEVTREE_CONST struct device *DEVTREE_CONST __pci_0_12_2 = &_dev15;
DEVTREE_CONST struct device *DEVTREE_CONST __pci_0_13_0 = &_dev16;
DEVTREE_CONST struct device *DEVTREE_CONST __pci_0_13_2 = &_dev17;
DEVTREE_CONST struct device *DEVTREE_CONST __pci_0_14_0 = &_dev18;
DEVTREE_CONST struct device *DEVTREE_CONST __pci_0_14_2 = &_dev19;
DEVTREE_CONST struct device *DEVTREE_CONST __pci_0_14_3 = &_dev20;
DEVTREE_CONST struct device *DEVTREE_CONST __pci_0_14_7 = &_dev21;
DEVTREE_CONST struct device *DEVTREE_CONST __pci_0_16_0 = &_dev22;
DEVTREE_CONST struct device *DEVTREE_CONST __pci_0_16_2 = &_dev23;
DEVTREE_CONST struct device *DEVTREE_CONST __pci_0_18_0 = &_dev24;
DEVTREE_CONST struct device *DEVTREE_CONST __pci_0_18_1 = &_dev25;
DEVTREE_CONST struct device *DEVTREE_CONST __pci_0_18_2 = &_dev26;
DEVTREE_CONST struct device *DEVTREE_CONST __pci_0_18_3 = &_dev27;
DEVTREE_CONST struct device *DEVTREE_CONST __pci_0_18_4 = &_dev28;
DEVTREE_CONST struct device *DEVTREE_CONST __pci_0_18_5 = &_dev29;
DEVTREE_CONST struct device *DEVTREE_CONST __pnp_002e_00 = &_dev30;
DEVTREE_CONST struct device *DEVTREE_CONST __pnp_002e_01 = &_dev31;
DEVTREE_CONST struct device *DEVTREE_CONST __pnp_002e_02 = &_dev32;
DEVTREE_CONST struct device *DEVTREE_CONST __pnp_002e_03 = &_dev33;
DEVTREE_CONST struct device *DEVTREE_CONST __pnp_002e_04 = &_dev34;
DEVTREE_CONST struct device *DEVTREE_CONST __pnp_002e_05 = &_dev35;
DEVTREE_CONST struct device *DEVTREE_CONST __pnp_002e_06 = &_dev36;
DEVTREE_CONST struct device *DEVTREE_CONST __pnp_002e_07 = &_dev37;
DEVTREE_CONST struct device *DEVTREE_CONST __pnp_004e_00 = &_dev38;
