#!/bin/sh
###
### https://review.coreboot.org/c/coreboot/+/33509
### csb_patcher.sh: gets,checks,installs the coreboot and SeaBIOS patches
###
rm -f "./csb_patcher.sh"
rm -f "./b91dcbb.diff" && rm -f "./patch?zip"
wget "https://review.coreboot.org/changes/33509/revisions/1/patch?zip"
unzip "./patch?zip" && rm -f "./patch?zip"
sha256sum_correct="d932d43aac1c0e3b79ed63c5dad26eb194fe8e6e6f45570058eac69b3df594e0  ./b91dcbb.diff"
sha256sum_my=$(sha256sum "./b91dcbb.diff")
printf "\n=== sha256sum should be\n$sha256sum_correct\n"
if [ "$sha256sum_my" = "$sha256sum_correct" ] ; then
    printf "^^^ this is correct, will extract a ./csb_patcher.sh script now...\n"
    patch -p1 < "./b91dcbb.diff"
    chmod +x "./csb_patcher.sh"
    printf "\nRun ./csb_patcher.sh help or ./csb_patcher.sh usage for more information.\n\n"
    exit 0
else
    printf "^^^ ! MISMATCH ! Check sha256sum manually: sha256sum ./b91dcbb.diff\n"
    exit 1
fi
