#!/bin/sh
###
### https://review.coreboot.org/c/coreboot/+/31357
### src/mainboard/lenovo/g505s: Disable SeaBIOS options not supported by hardware
###
patch -p1 < ./315fe68.diff
###
### https://review.coreboot.org/c/coreboot/+/31448
### src/device/pci: Add support for discrete VGA initialization and OpROM loading
###
patch -p1 < ./a70e9d9.diff
###
### https://review.coreboot.org/c/coreboot/+/31450
### lenovo/g505s: Add the discrete VGA support for AMD Lenovo G505S laptop
###
patch -p1 < ./9ee326e.diff
