#!/bin/sh

rom_extractor () {
    if [ ! -f ./pci1002\,$1.rom.txt ]; then
        echo "./pci1002,$1.rom.txt not found!"
        exit 1
    fi
    xxd -r ./pci1002\,$1.rom.txt > ./pci1002\,$1.rom
}

rm -f ./pci1002\,*.rom

###
### 6104e6989ea3f494d7bfa30573bf38e830f1068bab9980caec5e890e0ccbfced
### ./pci1002,990b.rom - Lenovo G505S with A10-5750M APU installed:
###                              for integrated GPU (iGPU) HD-8650G
###
rom_extractor "990b"
###
### 6052b5def3fda2a93f6c4d55ec91b819429e212e26cdb8e0fcca54599c9c92ed
### ./pci1002,6663.rom - Lenovo G505S with A10-5750M APU installed:
###                              for discrete GPU (dGPU) HD-8570M
###
rom_extractor "6663"
###
### 15d74515332bc512de66e0dc910d8600aeb134bf715bbc34a4faac0257f4a0dc
### ./pci1002,6665.rom - Lenovo G505S with A10-5750M APU installed:
###                              for discrete GPU (dGPU) R5-M230
###
rom_extractor "6665"
###
### cf5ad6f562cda07c8455a5fd33aae49ee6f451561a758e9761d1788767348115
### ./pci1002,9830.rom - ASUS AM1I-A with Athlon-5370 APU installed:
###                          for integrated GPU (iGPU) HD-8400 / R3-Series
###
rom_extractor "9830"
###
### 73d52887c5c0797a00c38ff1d26528f32620efe41b47c592aa295f008712d0e5
### ./pci1002,990c.rom - ASUS A88XM-E with A10-6700 APU installed:
###                          for integrated GPU (iGPU) HD-8670D
###
rom_extractor "990c"

echo "Extracted the AtomBIOS ROMs, please run ./check_atombios_roms.sh"
exit 0
