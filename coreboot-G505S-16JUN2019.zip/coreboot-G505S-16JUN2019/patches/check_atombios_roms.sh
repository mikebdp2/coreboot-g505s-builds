#!/bin/sh
rm -f ./sha256sums_atombios_my.txt
sha256sum ./pci1002\,990b.rom > ./sha256sums_atombios_my.txt
sha256sum ./pci1002\,6663.rom >> ./sha256sums_atombios_my.txt
sha256sum ./pci1002\,6665.rom >> ./sha256sums_atombios_my.txt
sha256sum ./pci1002\,9830.rom >> ./sha256sums_atombios_my.txt
sha256sum ./pci1002\,990c.rom >> ./sha256sums_atombios_my.txt
if cmp -s "./sha256sums_atombios_my.txt" "./sha256sums_atombios_correct.txt"
then
    echo "SHA256 checksums are correct. Use these AtomBIOS ROMs at your coreboot .config :"
    echo "   ( * ~ 'pci1002,' )      Lenovo G505S with A10-5750M APU installed:"
    echo "*990b.rom = iGPU HD-8650G | *6663.rom = dGPU HD-8570M / *6665.rom = dGPU R5-M230"
    echo "ASUS AM1I-A with Athlon-5370 APU installed: *9830.rom = iGPU HD-8400 / R3-Series"
    echo "ASUS A88XM-E with A10-6700 APU installed:   *990c.rom = iGPU HD-8670D"
    exit 0
else
    echo "! MISMATCH ! See ./sha256sums_atombios_my.txt and ./sha256sums_atombios_correct.txt"
    exit 1
fi
