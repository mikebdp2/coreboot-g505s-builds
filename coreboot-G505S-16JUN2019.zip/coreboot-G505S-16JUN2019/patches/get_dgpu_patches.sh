#!/bin/sh
###
### https://review.coreboot.org/c/coreboot/+/31357
### src/mainboard/lenovo/g505s: Disable SeaBIOS options not supported by hardware
###
rm -f ./315fe68.diff
wget https://review.coreboot.org/changes/31357/revisions/8/patch?zip
unzip ./patch\?zip && rm -f ./patch\?zip # && patch -p1 < ./315fe68.diff
###
### https://review.coreboot.org/c/coreboot/+/31448
### src/device/pci: Add support for discrete VGA initialization and OpROM loading
###
rm -f ./a70e9d9.diff
wget https://review.coreboot.org/changes/31448/revisions/16/patch?zip
unzip ./patch\?zip && rm -f ./patch\?zip # && patch -p1 < ./a70e9d9.diff
###
### https://review.coreboot.org/c/coreboot/+/31450
### lenovo/g505s: Add the discrete VGA support for AMD Lenovo G505S laptop
###
rm -f ./9ee326e.diff
wget https://review.coreboot.org/changes/31450/revisions/11/patch?zip
unzip ./patch\?zip && rm -f ./patch\?zip # && patch -p1 < ./9ee326e.diff
