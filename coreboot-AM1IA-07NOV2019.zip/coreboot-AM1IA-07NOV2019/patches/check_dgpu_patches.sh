#!/bin/sh
rm -f "./sha256sums_dgpu_my.txt"
sha256sum "./05b5785.diff" >  "./sha256sums_dgpu_my.txt"
sha256sum "./a08e433.diff" >> "./sha256sums_dgpu_my.txt"
if cmp -s "./sha256sums_dgpu_my.txt" "./sha256sums_dgpu_correct.txt"
then
    echo "SHA256 checksums are correct, please run ./apply_dgpu_patches.sh"
    exit 0
else
    echo "! MISMATCH ! See ./sha256sums_dgpu_my.txt and ./sha256sums_dgpu_correct.txt"
    exit 1
fi
#
