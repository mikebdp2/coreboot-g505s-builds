#!/bin/sh
###
### https://review.coreboot.org/c/coreboot/+/33871
### src/mainboard/asus/am1i-a: Disable SeaBIOS options not supported by hardware
###
rm -f "./4f752f0.diff"
wget "https://review.coreboot.org/changes/33871/revisions/2/patch?zip"
unzip "./patch?zip" && rm -f "./patch?zip" # && patch -p1 < "./4f752f0.diff"
###
