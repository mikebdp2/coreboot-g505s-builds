#!/bin/sh
###
### https://review.coreboot.org/c/coreboot/+/33871
### src/mainboard/asus/am1i-a: Disable SeaBIOS options not supported by hardware
###
patch -p1 < "./4f752f0.diff"
###
