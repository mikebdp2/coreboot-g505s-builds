#!/bin/sh
#
#          csb_patcher.sh: coreboot and SeaBIOS patcher script.
#
#  Conveniently and securely gets, checks SHA256 and installs some of my
# patches from this page - https://review.coreboot.org/q/status:open+banon
#   and also gets a collection of useful floppy-based operating systems.
#      Please send your feedback to Mike Banon <mikebdp2@gmail.com>
#

# Keys
enter=$( printf '\015' )
ctrl_c=$( printf '\003' )
ctrl_x=$( printf '\030' )
ctrl_z=$( printf '\032' )

# Formatting
bold="\e[1m"
bred="\e[1;31m"
bgreen="\e[1;32m"
byellow="\e[1;33m"
bend="\e[0m"

# Asks a question '$1' and waits for Y/N user input, printing a decision - with '$2' message if Y.
yesno () {
    printf "$1 [Y/N] "
    yesno_old_stty_cfg=$( stty -g )
    stty raw -echo
    while true ; do
        yesno_answer=$( head -c 1 )
        case "$yesno_answer" in
            *"$ctrl_c"*|"$ctrl_x"*|"$ctrl_z"*)
                stty "$yesno_old_stty_cfg"
                printf "${bred}TERMINATED${bend}\n"
                exit 1
                ;;
            *"y"*|"Y"*)
                stty "$yesno_old_stty_cfg"
                printf "${bgreen}YES${bend}$2\n"
                return 0
                ;;
            *"n"*|"N"*)
                stty "$yesno_old_stty_cfg"
                printf "${byellow}NO${bend}\n"
                return 1
                ;;
        esac
    done
}

# Waits until a user presses Enter.
encontinue () {
    printf "\npress [ENTER] to continue... "
    encontinue_old_stty_cfg=$( stty -g )
    stty raw -echo
    while true ; do
        encontinue_answer=$( head -c 1 )
        case "$encontinue_answer" in
            *"$ctrl_c"*|"$ctrl_x"*|"$ctrl_z"*)
                stty "$encontinue_old_stty_cfg"
                printf "${bred}TERMINATED${bend}\n"
                exit 1
                ;;
            *"$enter"*)
                stty "$encontinue_old_stty_cfg"
                printf "\n"
                return 0
                ;;
	esac
    done
}

# Checks if a command '$1' exists.
command_exists() {
    if [ ! -x "$( command -v $1 )" ] ; then
        printf "\n${bred}ERROR${bend}: command ${bold}$1${bend} is not found !\n"
        encontinue
        return 1
    else
        return 0
    fi
}

# Checks if a file '$1' exists.
file_exists () {
    if [ ! -f "$1" ] ; then
        printf "\n${byellow}WARNING${bend}: file ${bold}$1${bend} is not found !\n"
        encontinue
        return 1
    else
        return 0
    fi
}

# Force removes a file '$2' and then copies a file '$1' to '$2'.
copier () {
    if file_exists "$1" ; then
        rm -f "$2"
        cp "$1" "$2"
        return 0
    else
        return 1
    fi
}

# Force removes a file '$2' and then moves a file '$1' to '$2'.
mover () {
    if file_exists "$1" ; then
        rm -f "$2"
        mv "$1" "$2"
        return 0
    else
        return 1
    fi
}

# Checks if line '$1' contains the text '$2'.
checker () {
    case "$1" in
        *"$2"*)
            return 0
            ;;
        *)
            return 1
            ;;
    esac
}

# Prints the lines of a file '$2' which contain the text '$1'.
grepper () {
    if file_exists "$2" ; then
        while IFS= read -r grepper_line
        do
            case "$grepper_line" in
            *"$1"*)
                printf '%s\n' "$grepper_line"
                ;;
        esac
        done < "$2"
        return 0
    else
        return 1
    fi
}

# Checks if a file '$2' contains the text '$1'.
grepcheck () {
    if file_exists "$2" ; then
        while IFS= read -r grepcheck_line
        do
            case "$grepcheck_line" in
                *"$1"*)
                    return 0
                    ;;
            esac
        done < "$2"
        return 1
    else
        return 1
    fi
}

# Replaces the lines containing the text '$2' of a file '$1' with a line '$3'.
sedder () {
    if file_exists "$1" ; then
        csb_sedder_tmp="./.csb_sedder"
        rm -f "$csb_sedder_tmp"
        while IFS= read -r sedder_line
        do
            case "$sedder_line" in
                *"$2"*)
                    if [ ! -z "$3" ] ; then
                        printf '%s\n' "$3" >> "$csb_sedder_tmp"
                    fi
                    ;;
                *)
                    printf '%s\n' "$sedder_line" >> "$csb_sedder_tmp"
                    ;;
            esac
        done < "$1"
        mover "$csb_sedder_tmp" "$1"
        return 0
    else
        return 1
    fi
}

# Downloads a file '$1' from a link '$2' using the options '$3' and checks if this was successful.
wgetter () {
    rm -f "$1"
    if [ -z "$3" ] ; then
        wget "$2"
    else
        wget "$3" "$2"
    fi
    if [ -f "$1" ] ; then
        wgetter_file_size=$(($( wc -c < "$1" )))
        if [ "$wgetter_file_size" -eq "0" ] ; then
            rm -f "$1"
        fi
    fi
    if [ ! -f "$1" ] ; then
        printf "\n${byellow}WARNING${bend}: can't download a ${bold}$1${bend} file !"
        printf "\n         Please check your Internet connection and try again.\n"
        encontinue
        return 1
    else
        return 0
    fi
}

# Unzips the archive '$1', optional '$2' for -j path inside the archive, and then force removes it.
unzipper () {
    if file_exists "$1" ; then
        if [ -z "$2" ] ; then
            unzip "$1"
        else
            unzip -j "$1" "$2"
        fi
        rm -f "$1"
        return 0
    else
        return 1
    fi
}

# Expands a file '$1' with zeroes using a dd to '$2' size - e.g. to a standard floppy size 1474560.
expander () {
    if file_exists "$1" && [ ! -z "$2" ] ; then
        expander_file_size=$(($( wc -c < "$1" )))
        if [ "$expander_file_size" -lt "$2" ] ; then
            dd if=/dev/zero of=$1 bs=1 count=1 seek="$(( $2 - 1 ))" conv=notrunc iflag=nocache
        fi
        return 0
    else
        return 1
    fi
}

# Compares sha256sum of '$1.img' floppy image with '$2' and creates a hidden '.$1' file if matches.
floppy_verifier () {
    rm -f "./.$1"
    cd "./../"
    if [ ! -z "$2" ] ; then
        if file_exists "./floppies/$1.img" ; then
            floppy_verifier_sha256sum_correct="$2  ./floppies/$1.img"
            floppy_verifier_sha256sum_my=$( sha256sum "./floppies/$1.img" )
            printf "\n=== sha256sum should be:\n${bold}$floppy_verifier_sha256sum_correct${bend}\n"
            if [ "$floppy_verifier_sha256sum_my" = "$floppy_verifier_sha256sum_correct" ] ; then
                printf "^^^ this is correct, ./floppies/${bold}$1.img${bend} is verified and could be added.\n\n"
                cd "./floppies/"
                touch "./.$1"
                return 0
            else
                printf "${bold}^^^ ! MISMATCH for ./floppies/$1.img ! Check sha256sum manually: sha256sum ./floppies/$1.img${bend}\n"
                encontinue
                cd "./floppies/"
                return 1
            fi
        else
            printf "\n${byellow}WARNING${bend}: cannot find ./floppies/${bold}$1.img${bend} !\n"
            printf "\n         Please re-download a set of floppies.\n"
            encontinue
            return 1
        fi
    else
        printf "\n${byellow}WARNING${bend}: ./floppies/${bold}$1.img${bend} - is a rolling release, its' SHA256 checksum"
        printf "\n         is changing constantly and not provided by $1 project, so not checked.\n"
        encontinue
        cd "./floppies/"
        touch "./.$1"
        return 0
    fi
}

# Downloads a collection of floppies, for the purpose of adding them later to a coreboot ROM image.
floppy_mass_downloader () {
    printf "\n"
    if [ ! -d "./floppies/" ]; then
        mkdir "./floppies/"
    fi
    cd "./floppies/"
    # KOLIBRI
    if command_exists "7za" ; then
        if wgetter "./latest-img.7z" "https://builds.kolibrios.org/eng/latest-img.7z" ; then
            rm -f "./kolibri.img"
            7za x "./latest-img.7z"
            rm -f "./latest-img.7z"
           floppy_verifier "kolibri" "" # IS A ROLLING RELEASE, NO SHA256 VERIFICATION
        fi
    else
        printf "\n${byellow}WARNING${bend}: cannot get ./floppies/${bold}kolibri.img${bend} without ${bold}7za${bend}\n"
        encontinue
    fi
    # FREEDOS
    if wgetter "./FD12FLOPPY.zip" "https://www.freedos.org/download/download/FD12FLOPPY.zip" ; then
        unzipper "./FD12FLOPPY.zip" "FLOPPY.img"
        mover "./FLOPPY.img" "./freedos.img"
           floppy_verifier "freedos" "de2fb84dc2f132324549e89d58c6383497ec1af538c5b0ecde389fb748b9d537"
    fi
    # MICHALOS
    printf "\n${byellow}WARNING${bend}: getting ./floppies/${bold}michalos.img${bend} could take a couple of minutes...\n\n"
    if wgetter "./MichalOS.zip" "https://sourceforge.net/projects/michalos/files/MichalOS%202.1/MichalOS.zip" "--content-disposition" ; then
        unzipper "./MichalOS.zip" "disk_images/michalos.img"
          floppy_verifier "michalos" "3e072552bcb39fffc4ed8c2e144cfecb6b98f90046e82a3690801a1bd3befcf9"
    fi
    # SNOWDROP
    if wgetter "./snowdrop.img" "http://sebastianmihai.com/downloads/snowdrop/snowdrop.img" ; then
          floppy_verifier "snowdrop" "" # IS A ROLLING RELEASE, NO SHA256 VERIFICATION
    fi
    # FIWIX
    if wgetter "./fiwix.img" "https://www.fiwix.org/fiwix-1.0.1-i386-initrd.img" "--output-document=fiwix.img" ; then
             floppy_verifier "fiwix" "dbec2994ec619c9954327ab0b983ab24cd362406a2e515c35c79c79bd6417cfd"
    fi
    # MEMTEST
    if wgetter "./memtest86+-5.01.floppy.zip" "https://www.memtest.org/download/5.01/memtest86+-5.01.floppy.zip" ; then
        unzipper "./memtest86+-5.01.floppy.zip" "floppy/memtestp.bin"
        expander "./memtestp.bin" "1474560"
        mover "./memtestp.bin" "./memtest.img"
           floppy_verifier "memtest" "364535abd0d105da9396df6015e480c4d4c52b07dcc4e1d4756bde8ef87a30f1"
    fi
    # TATOS
    if wgetter "./tatos.img" "https://github.com/tatimmer/tatOS/raw/master/tatOS.img" "--output-document=tatos.img" ; then
        expander "./tatos.img" "1474560"
             floppy_verifier "tatos" "2c66f884498a4fe7b469bc213aebfccd84a09fd7ace1b3b4b3e747e2392c35d1"
    fi
    # PLOP
    if wgetter "./plpbt-5.0.15.zip" "https://download.plop.at/files/bootmngr/plpbt-5.0.15.zip" ; then
        unzipper "./plpbt-5.0.15.zip" "plpbt-5.0.15/plpbt.img"
        mover "./plpbt.img" "./plop.img"
              floppy_verifier "plop" "f170759966ec4efe60c8531158344a234d7543c8de81e54c8c1bb9d2d69eaf27"
    fi
    # FLOPPYBIRD
    if wgetter "./floppybird.img" "https://github.com/mikebdp2/floparchive/raw/master/floppies_extra/floppybird.img" ; then
        floppy_verifier "floppybird" "5db1b469e25e9eda7b8c0f666d6b655bab083c85618a9453ee72f1201cca840f"
    fi
    # Some floppies have the weird permissions after their extraction
    floppy_mass_downloader_floppies=$( find . -name "*.img" )
    if [ ! -z "$floppy_mass_downloader_floppies" ] ; then
        chmod 755 "./"*".img"
    fi
    # Return back to ./coreboot/
    cd "./../"
    return 0
}

# Adds a './pci1002,$1.rom' to coreboot '$3' ROM using '$2' cbfstool, printing '$4'/'$5'/'$6' info.
atombios_adder () {
    if file_exists "$2" && file_exists "$3" ; then
        if [ -f "./pci1002,$1.rom" ] ; then
            atombios_adder_cbfs=$( "$2" "$3" print )
            if checker "$atombios_adder_cbfs" "pci1002,$1.rom" ; then
                printf "\n${bgreen}NOTE${bend}: ./${bold}pci1002,$1.rom${bend} for ${bold}$5 : $6${bend} is already at your $3.\n"
            else
                if yesno "\nAdd a ./${bold}pci1002,$1.rom${bend} for ${bold}$5 : $6${bend} to your $3 now? ${bold}~$4${bend}" ", adding..." ; then
                    "$2" "$3" add -f "./pci1002,$1.rom" -n "pci1002,$1.rom" -t optionrom
                else
                    printf "\n${bold}You can add it later by running:${bend}"
                    printf "\n${bold}        $2 $3 add -f ./pci1002,$1.rom -n pci1002,$1.rom -t optionrom${bend}\n\n"
                fi
            fi
            return 0
        else
            printf "\n${byellow}WARNING${bend}: cannot find ./${bold}pci1002,$1.rom${bend} ,"
            printf "\n         please re-apply ${bold}AMD atombios${bend} patch.\n"
            encontinue
            return 1
        fi
    else
        return 1
    fi
}

# Adds a '$1.img' floppy image to coreboot '$3' ROM using '$2' cbfstool, printing '$4' size info.
floppy_adder () {
    if file_exists "$2" && file_exists "$3" ; then
        if [ -f "./floppies/$1.img" ] ; then
            if [ -f "./floppies/.$1" ] ; then
                floppy_adder_cbfs=$( "$2" "$3" print )
                if checker "$floppy_adder_cbfs" "floppyimg/$1.lzma" ; then
                    printf "\n${bgreen}NOTE${bend}: ./floppies/${bold}$1.img${bend} is already at your $3.\n"
                else
                    if checker "$1" "plop" ; then
                        printf "\n${byellow}WARNING${bend}: ./floppies/${bold}$1.img${bend} - is proprietary: all its' source code is closed !"
                        printf "\n         Add it only if you really need it and trust the author of $1 project.\n"
                        encontinue
                    fi
                    if yesno "\nAdd a ./floppies/${bold}$1.img${bend} to your $3 now? ${bold}~$4${bend}" ", adding..." ; then
                        "$2" "$3" add -f "./floppies/$1.img" -n "floppyimg/$1.lzma" -t raw -c lzma
                    else
                        printf "\n${bold}You can add it later by running:${bend}"
                        printf "\n${bold}        $2 $3 add -f ./floppies/$1.img -n floppyimg/$1.lzma -t raw -c lzma${bend}\n\n"
                    fi
                fi
                return 0
            else
                printf "\n${byellow}WARNING${bend}: there was a SHA256 mismatch for ./floppies/${bold}$1.img${bend} -"
                printf "\n         check sha256sum manually: sha256sum ./floppies/${bold}$1.img${bend}\n"
                encontinue
                return 1
            fi
        else
            printf "\n${byellow}WARNING${bend}: cannot find ./floppies/${bold}$1.img${bend} !\n"
            printf "\n         Please re-download a set of floppies.\n"
            encontinue
            return 1
        fi
    else
        return 1
    fi
}

# Adds a set of AtomBIOS/floppies ('$1') to coreboot '$3' ROM copied to '$4', using '$2' cbfstool.
cbfs_mass_adder () {
    if ! grepcheck "how to submit coreboot changes" ./MAINTAINERS ; then
        printf "\n${byellow}WARNING${bend}: not sure if I am inside the coreboot directory,"
        printf "\n         trying to add a ${bold}$1${bend} set from here - could fail.\n\n"
    fi
    if file_exists "$2" && file_exists "$3" ; then
        if checker "$1" "atom" || checker "$1" "flop" ; then
            copier "$3" "$4"
            printf "\n${bold}=== $4 - initial memory map${bend}\n\n"
            "$2" "$4" print
            printf "\n"
            if checker "$1" "atom" ; then
###
### https://review.coreboot.org/c/coreboot/+/33886
### G505S AtomBIOS ROMs: known good binaries with a script to check their SHA256
###
           csb_patcher "atombios" "33886"  "1" "0687d68" "c4cc7de2ee48ed28fe6d1067aa5151f579f9ea7b58213b8e45da17720dc8e1e7" "$1" "AMD "
                atombios_adder "990b" "$2" "$4" "62K" "Lenovo G505S with A10-5750M"  "iGPU HD-8650G"
                atombios_adder "6663" "$2" "$4" "33K" "Lenovo G505S with A10-5750M"  "dGPU HD-8570M"
                atombios_adder "6665" "$2" "$4" "32K" "Lenovo G505S with A10-5750M"  "dGPU R5-M230"
                atombios_adder "9830" "$2" "$4" "59K" "ASUS AM1I-A with Athlon-5370" "iGPU HD-8400 / R3-Series"
                atombios_adder "990c" "$2" "$4" "62K" "ASUS A88XM-E with A10-6700"   "iGPU HD-8670D"
            fi
            if checker "$1" "flop" ; then
                if [ ! -d "./floppies/" ] ; then
                    printf "\n"
                    floppy_mass_downloader
                fi
                # Default boot order: the last floppy added - is the first floppy to boot!
                floppy_adder "floppybird" "$2" "$4"    "3K"
                      floppy_adder "plop" "$2" "$4"   "75K"
                     floppy_adder "tatos" "$2" "$4"   "60K"
                   floppy_adder "memtest" "$2" "$4"   "45K"
                     floppy_adder "fiwix" "$2" "$4"  "459K"
                  floppy_adder "snowdrop" "$2" "$4"  "145K"
                  floppy_adder "michalos" "$2" "$4"  "257K"
                   floppy_adder "freedos" "$2" "$4"  "698K"
                   floppy_adder "kolibri" "$2" "$4" "1264K"
            fi
            printf "\n${bold}=== $4 - final memory map${bend}\n\n"
            "$2" "$4" print
            printf "\nYou can use ./build/${bold}coreflop.rom${bend} now !\n\n"
            return 0
        else
            return 1
        fi
    else
        return 1
    fi
}

# Finds the files of '$1' extension, saves the result to '$2' log and prints a message with '$3'.
csb_finder () {
    csb_finder_files=$( find . -name "*.$1" )
    if [ ! -z "$csb_finder_files" ] ; then
        printf "%25s\n" "*.$1 - YES" >> "$2"
        printf "\n${byellow}WARNING${bend}: found ${bold}*.$1${bend} files at these locations :\n"
        printf "$csb_finder_files"
        printf "\n  That means - Some patches $3\n"
        encontinue
        return 0
    else
        printf "%24s\n" "*.$1 - NO" >> "$2"
        return 1
    fi
}

# Prints a csb_patcher_log '$1' with a custom highlighting.
csb_printer () {
    if ! file_exists "$1" ; then
        return 1
    fi
    while IFS= read -r csb_printer_line
    do
        case "$csb_printer_line" in
            *"orig - YES"*)
                printf "${csb_printer_line%???}${byellow}YES" # YELLOW
                ;;
            *"rej - YES"*)
                printf "${csb_printer_line%???}${bred}YES" # RED
                ;;
            *"YES"*)
                printf "${csb_printer_line%???}${bgreen}YES" # GREEN
                ;;
            *"orig - NO"*|*"rej - NO"*)
                printf "${csb_printer_line%??}${bgreen}NO" # GREEN
                ;;
            *"NO"*)
                printf "${csb_printer_line%??}${byellow}NO" # YELLOW
                ;;
            *"FAILURE_1"*)
                printf "${csb_printer_line%?????????}${bred}FAILURE_1" # RED
                ;;
            *"FAILURE_2"*)
                printf "${csb_printer_line%?????????}${bred}FAILURE_2" # RED
                ;;
            *"FAILURE_3"*)
                printf "${csb_printer_line%?????????}${bred}FAILURE_3" # RED
                ;;
            *"\\\\"*)
                printf "${bold}${csb_printer_line%?????}\\\\\!//" # ALIEN HAIR
                ;;
            *)
                printf "${bold}$csb_printer_line"
                ;;
        esac
        printf "${bend}\n"
    done < "$1"
    return 0
}

# Configure some popular options of a config file '$1'.
csb_configurer () {
    if file_exists "$1" ; then
        csb_configurer_tmp="./.csb_configurer"
        rm -f "$csb_configurer_tmp"
        # Check if the configuration of this board is supported.
        grepper "CONFIG_BOARD_" "$1" > "$csb_configurer_tmp"
        if grepcheck "_LENOVO_G505S=y" "$csb_configurer_tmp" ; then
            printf "\n\n${bgreen}[CONFIG]${bend} Questions about your Lenovo G505S\n\n"
        else
            if grepcheck "_ASUS_AM1I_A=y" "$csb_configurer_tmp" ; then
                printf "\n\n${bgreen}[CONFIG]${bend} Questions about your ASUS AM1I-A\n\n"
            else
                printf "\n\n${byellow}WARNING${bend}: sorry, I don't know how to configure a board of ${bold}$1${bend}\n"
                encontinue
                return 1
            fi
        fi
        # Common part both for LENOVO G505S and ASUS AM1I-A.
        sedder "$1" "### CSB_CONFIGURER OPTIONS" ""
        printf "### CSB_CONFIGURER OPTIONS\n" >> "$1"
        sedder "$1" "# CONFIG_DRIVERS_INTEL_WIFI is not set" ""
        if ! yesno "Do you have an Intel WiFi adapter?" "" ; then
            printf "# CONFIG_DRIVERS_INTEL_WIFI is not set\n" >> "$1"
        fi
        # This part is only for LENOVO G505S.
        if grepcheck "_LENOVO_G505S=y" "$csb_configurer_tmp" ; then
            sedder "$1" "CONFIG_MULTIPLE_VGA_ADAPTERS=y" ""
            sedder "$1" "CONFIG_VGA_BIOS_DGPU=y" ""
            sedder "$1" "CONFIG_VGA_BIOS_DGPU_FILE=\"pci1002,6663.rom\"" ""
            sedder "$1" "CONFIG_VGA_BIOS_DGPU_ID=\"1002,6663\"" ""
            sedder "$1" "CONFIG_VGA_BIOS_DGPU_FILE=\"pci1002,6665.rom\"" ""
            sedder "$1" "CONFIG_VGA_BIOS_DGPU_ID=\"1002,6665\"" ""
            if yesno "Do you have a Discrete GPU?" "" ; then
                printf "CONFIG_MULTIPLE_VGA_ADAPTERS=y\n" >> "$1"
                printf "CONFIG_VGA_BIOS_DGPU=y\n"         >> "$1"
                if yesno "No for HD-8570M, Yes for R5-M230" "" ; then
                    printf "CONFIG_VGA_BIOS_DGPU_FILE=\"pci1002,6665.rom\"\n" >> "$1"
                    printf "CONFIG_VGA_BIOS_DGPU_ID=\"1002,6665\"\n"          >> "$1"
                else
                    printf "CONFIG_VGA_BIOS_DGPU_FILE=\"pci1002,6663.rom\"\n" >> "$1"
                    printf "CONFIG_VGA_BIOS_DGPU_ID=\"1002,6663\"\n"          >> "$1"
                fi
            fi
        fi
        # Common part both for LENOVO G505S and ASUS AM1I-A.
        # HUDSON_SATA_MODE=0
        sedder "$1" "# NATIVE" ""
        sedder "$1" "CONFIG_HUDSON_SATA_MODE=0" ""
        # HUDSON_SATA_MODE=1
        sedder "$1" "# RAID" ""
        sedder "$1" "CONFIG_HUDSON_SATA_MODE=1" ""
        sedder "$1" "CONFIG_RAID_ROM_ID=\"1022,7802\"" ""
        sedder "$1" "CONFIG_RAID_ROM_FILE=\"src/southbridge/amd/agesa/hudson/raid.bin\"" ""
        sedder "$1" "CONFIG_RAID_MISC_ROM_FILE=\"src/southbridge/amd/agesa/hudson/misc.bin\"" ""
        sedder "$1" "CONFIG_RAID_MISC_ROM_POSITION=0xFFF00000" ""
        # HUDSON_SATA_MODE=2
        sedder "$1" "# AHCI" ""
        sedder "$1" "CONFIG_HUDSON_SATA_MODE=2" ""
        sedder "$1" "CONFIG_AHCI_ROM_ID=\"1022,7801\"" ""
        sedder "$1" "# CONFIG_HUDSON_AHCI_ROM is not set" ""
        # HUDSON_SATA_MODE=3
        sedder "$1" "# LEGACY IDE" ""
        sedder "$1" "CONFIG_HUDSON_SATA_MODE=3" ""
        # HUDSON_SATA_MODE=4
        sedder "$1" "# IDE to AHCI" ""
        sedder "$1" "CONFIG_HUDSON_SATA_MODE=4" ""
        # HUDSON_SATA_MODE=5
        sedder "$1" "# AHCI7804" ""
        sedder "$1" "CONFIG_HUDSON_SATA_MODE=5" ""
        sedder "$1" "CONFIG_AHCI_ROM_ID=\"1022,7804\"" ""
        # HUDSON_SATA_MODE=6
        sedder "$1" "# IDE to AHCI7804" ""
        sedder "$1" "CONFIG_HUDSON_SATA_MODE=6" ""
        sedder "$1" "# CONFIG_HUDSON_AHCI_ROM is not set" ""
        # HUDSON_SATA_MODE SETUP
        if yesno "Do you have a SSD? (enable AHCI if Y)" "" ; then
            printf "# AHCI\n" >> "$1"
            printf "CONFIG_HUDSON_SATA_MODE=2\n" >> "$1"
            printf "CONFIG_AHCI_ROM_ID=\"1022,7801\"\n" >> "$1"
            printf "# CONFIG_HUDSON_AHCI_ROM is not set\n" >> "$1"
        else
            printf "# NATIVE\n" >> "$1"
            printf "CONFIG_HUDSON_SATA_MODE=0\n" >> "$1"
        fi
        # Board has been configured.
        printf "\n"
        rm -f "$csb_configurer_tmp"
        return 0
    else
        return 1
    fi
}

#
# Conveniently and securely gets, checks SHA256 and installs a patch.
# Arguments are the patch properties:
#     $1 - new diff name, could be also a part of extracted scripts' filename
#     $2 - change ID number,       part of download link to review.coreboot.org
#     $3 - change revision number, part of download link to review.coreboot.org
#     $4 - diff filename inside the downloaded archive, will be renamed to $1
#     $5 - diff known good SHA256 checksum, will be used for SHA256 verification
#     $6 - filepath where to save a csb_patcher_log which will be printed later
#     $7 - info about the target of a patch, if not specified ("") it is common
#
csb_patcher () {
    if ! wgetter "./patch?zip" "https://review.coreboot.org/changes/$2/revisions/$3/patch?zip" ; then
        printf "${bold}^^^ ! Can't download a $7$1 patch ! Check your Internet.${bend}\n"
        printf "%31s\n" "$7$1 - FAILURE_1" >> "$6"
        csb_printer "$6"
        exit 1
    fi
    unzipper "./patch?zip"
    mover "./$4.diff" "./$1.diff"
    csb_patcher_sha256sum_correct="$5  ./$1.diff"
    csb_patcher_sha256sum_my=$( sha256sum "./$1.diff" )
    printf "\n=== sha256sum should be:\n${bold}$csb_patcher_sha256sum_correct${bend}\n"
    if [ "$csb_patcher_sha256sum_my" = "$csb_patcher_sha256sum_correct" ] ; then
        printf "^^^ this is correct, "
        csb_patcher_patch_title=$( grepper "Subject" "./$1.diff" )
        csb_patcher_patch_title=${csb_patcher_patch_title#?????????????????}
        if [ "$1" = "dgpu" ] || [ "$1" = "cfgsb" ] ; then
            printf "will extract a ${bold}$7$1${bend} patch now...\n"
            rm -f "./sha256sums_$1_correct.txt"
            rm -f "./"*"_$1_patches.sh"
            patch -p1 < "./$1.diff"
            chmod +x "./"*"_$1_patches.sh"
            "./get_$1_patches.sh"
            if ! "./check_$1_patches.sh" ; then
                printf "%31s\n" "$7$1 - FAILURE_3" >> "$6"
                csb_printer "$6"
                exit 1
            fi
        else
            printf "${bold}$7$1${bend} patch could be applied now...\n"
        fi
        if [ "$1" = "dgpu" ] || [ "$1" = "atombios" ] || \
           [ "$1" = "tint" ] || [ "$1" = "seabios" ] || [ "$1" = "cfgsb" ] ; then
            printf "\n\n${bgreen}[PATCH]${bend} $csb_patcher_patch_title\n\n"
            if ! grepcheck "how to submit coreboot changes" ./MAINTAINERS ; then
                printf "\n${byellow}WARNING${bend}: not sure if I am inside the coreboot directory,"
                printf "\n         trying to add a ${bold}$1${bend} set from here - could fail.\n\n"
            fi
            if [ -f "./.$1" ] ; then
                printf "\n${byellow}WARNING${bend}: found a '.$1' hidden file at the current directory,"
                printf "\n         maybe you have applied this patch already.\n\n"
            fi
            if yesno "Apply a ${bold}$7$1${bend} patch now?" "" ; then
                if [ "$1" = "dgpu" ] || [ "$1" = "cfgsb" ] ; then
                    "./apply_$1_patches.sh"
                else
                    if [ "$1" = "atombios" ] ; then
                        rm -f "./sha256sums_$1_correct.txt"
                        rm -f "./"*"_$1_roms.sh"
                        rm -f "./pci1002\,"*".rom"
                        rm -f "./pci1002\,"*".rom.txt"
                    fi
                    if [ "$1" = "tint" ] ; then
                        rm -f "./payloads/external/tint/tint.sh"
                        rm -f "./payloads/external/tint/"*"_core.sh"
                        rm -f "./payloads/external/tint/tint-0.04-nmu1_libpayload.patch"
                    fi
                    if [ "$1" = "seabios" ] ; then
                        rm -f "./payloads/external/SeaBIOS/"*".patch"
                    fi
                    patch -p1 < "./$1.diff"
                    if [ "$1" = "atombios" ] ; then
                        chmod +x "./"*"_$1_roms.sh"
                        "./extract_$1_roms.sh"
                        printf "\n"
                        if ! "./check_$1_roms.sh" ; then
                            printf "%31s\n" "$7$1 - FAILURE_3" >> "$6"
                            csb_printer "$6"
                            exit 1
                        fi
                    fi
                    if [ "$1" = "tint" ] ; then
                        chmod +x "./payloads/external/tint/"*"_core.sh"
                    fi
                fi
                touch ".$1"
                printf "%25s\n" "$7$1 - YES" >> "$6"
                if [ "$1" = "atombios" ] ; then
                    encontinue
                fi
            else
                printf "%24s\n" "$7$1 - NO" >> "$6"
                printf "\n${bold}You can apply it later by running:${bend}"
                if [ "$1" = "dgpu" ] || [ "$1" = "cfgsb" ]; then
                    printf "\n${bold}        ./apply_$1_patches.sh${bend}\n"
                else
                    printf "\n${bold}        patch -p1 < ./$1.diff${bend}\n"
                fi
                encontinue
            fi
        fi
        if checker "$1" "config" ; then
            rm -f "./configs/$1"*
            patch -p1 < "./$1.diff"
            printf "\n\n${bgreen}[PATCH]${bend} $csb_patcher_patch_title\n\n"
            ls "./configs" > "./.csb_configs"
            csb_patcher_config_name=$( grepper "$1" "./.csb_configs" )
            rm -f "./.csb_configs"
            printf "\n${bold}$csb_patcher_config_name could now be found at ./configs/${bend}"
            printf "\n${bold}To use it, it should be copied to '.config' of your ./coreboot directory.${bend}\n\n"
            if [ -f "./.config" ] ; then
                printf "\n${byellow}WARNING${bend}: copying it to ./.config will overwrite your current '.config'\n\n"
            fi
            if yesno "Copy it to ./.config now?" "" ; then
                copier "./configs/$csb_patcher_config_name" "./.config"
                printf "\n"
                printf "%25s\n" "$7$1 - YES" >> "$6"
                if yesno "Configure this ./.config now?" "" ; then
                    csb_configurer "./.config"
                else
                    printf "\n${bold}You can configure it later by running:${bend}"
                    printf "\n${bold}        ./csb_patcher.sh config${bend}\n\n"
                fi
            else
                printf "%24s\n" "$7$1 - NO" >> "$6"
                printf "\n${bold}You can copy it later by running:${bend}"
                printf "\n${bold}        cp ./configs/$csb_patcher_config_name ./.config${bend}\n"
            fi
            printf "\n${byellow}WARNING${bend}: important README at the beginning of ./$1.diff\n"
            encontinue
        fi
        printf "\n\n"
        return 0
    else
        printf "${bold}^^^ ! MISMATCH for a $7$1 patch ! Check sha256sum manually: sha256sum ./$1.diff${bend}\n"
        printf "%31s\n" "$7$1 - FAILURE_2" >> "$6"
        csb_printer "$6"
        exit 1
    fi
}

#
# Conveniently and securely gets, checks SHA256 and applies my collection of unofficial patches.
#     $1 - filepath where to save a csb_patcher_log which will be printed later
#
csb_mass_patcher () {
###
### https://review.coreboot.org/c/coreboot/+/33874
### G505S dGPU support: scripts for applying the unofficial (not-merged-yet) patches
###
               csb_patcher "dgpu" "33874"  "7" "7dedf37" "9f681dfa7874a9bd34778749f2405c14ea786e8a515957557536f11f0fbb2ba3" "$1" "G505S "
###
### https://review.coreboot.org/c/coreboot/+/33886
### G505S AtomBIOS ROMs: known good binaries with a script to check their SHA256
###
           csb_patcher "atombios" "33886"  "2" "6339853" "5c9458dbebfad86c65c93921a0b5ae52e34e0a68cb06ff655d4549cc9013b0cd" "$1" "AMD "
###
### https://review.coreboot.org/c/coreboot/+/33887
### tint: introduce the new tint build system with checksum verification
###
               csb_patcher "tint" "33887"  "2" "9c8151d" "6a389277d4d741ea09186f4fbb1960f0a39e40385192a3dadc244d1c590d5733" "$1" ""
###
### https://review.coreboot.org/c/coreboot/+/32351
### SeaBIOS patches: advanced_bootmenu, multiple_floppies, writeprotected_usb
###
            csb_patcher "seabios" "32351"  "7" "ff6f8a6" "d89128106a02c5f6ee2903ada0cd6efc2ca62871fed3d5b632e740f53425e43c" "$1" ""
###
### https://review.coreboot.org/c/coreboot/+/33885
### Disable SeaBIOS options not supported by hardware: scripts to apply the patches
###
              csb_patcher "cfgsb" "33885"  "4" "bae2957" "1da3da1d963e6c39dcc210787102919cb72752ac51065e41a176adc2980bdcb1" "$1" "for-configs "
###
### https://review.coreboot.org/c/coreboot/+/32352
### configs: add Lenovo G505S sample configuration (use with dGPU patches)
###
csb_patcher "config.lenovo_g505s" "32352" "19" "7ceb7d3" "5995047bc87ea430ecfd62f1c47f5b9aada88030284f357b21cc2124a727d6da" "$1" ""
###
### https://review.coreboot.org/c/coreboot/+/33800
### configs: add ASUS AM1I-A sample configuration
###
 csb_patcher "config.asus_am1i-a" "33800"  "6" "2a5b377" "c59aa95c54f1e6f17d48d0751049a242015e46d2a66b3c995849639ba8bbb750" "$1" ""

    return 0
}

# Prints a usage info for this ./csb_patcher.sh script.
csb_usage () {
    printf "${bold}===============${bend} ${bgreen}USAGE${bend} ${bold}================${bend}\n\n"
    printf "${bold}./csb_patcher.sh${bend}\n"
    printf "  patch your coreboot source code\n\n"
    printf "${bold}./csb_patcher.sh${bend} ${byellow}help${bend} ${bold}|${bend} ${byellow}usage${bend}\n"
    printf "  print this usage info\n\n"
    printf "${bold}==================== Before building :${bend}\n\n"
    printf "${bold}./csb_patcher.sh ${byellow}config${bend}\n"
    printf "  configure some popular options\n\n"
    printf "${bold}==================== After building :${bend}\n\n"
    printf "${bold}./csb_patcher.sh ${byellow}atom${bend}\n"
    printf "  add the AtomBIOS to coreboot.rom\n\n"
    printf "${bold}./csb_patcher.sh ${byellow}flop${bend}\n"
    printf "  add the floppies to coreboot.rom\n\n"
    printf "${bold}./csb_patcher.sh ${byellow}atomflop${bend}\n"
    printf "  both AtomBIOS VGA ROMs and floppies\n\n"
    printf "${bold}./csb_patcher.sh${bend} ${byellow}print${bend}\n"
    printf "     print a ./.csb_patcher log\n\n"
    return 0
}

#
# MAIN PART OF A CSB_PATCHER SCRIPT
#

if [ -z "$1" ] ; then
    csb_patcher_log="./.csb_patcher"
    rm -f "$csb_patcher_log"
    if ! command_exists "wget" || \
       ! command_exists "unzip" || \
       ! command_exists "sha256sum" || \
       ! command_exists "patch" ; then
        exit 1
    fi
    printf '\n\n'                                       >> "$csb_patcher_log"
    printf '                \\\\!//\n'                  >> "$csb_patcher_log"
    printf '                (o o)\n'                    >> "$csb_patcher_log"
    printf '            oOOo-(_)-oOOo\n'                >> "$csb_patcher_log"
    printf 'Hi! I am coreboot and SeaBIOS patcher\n'    >> "$csb_patcher_log"
    printf 'Please send your feedback to\n'             >> "$csb_patcher_log"
    printf '      Mike Banon <mikebdp2@gmail.com>\n'    >> "$csb_patcher_log"
    csb_printer "$csb_patcher_log"
    encontinue
    printf '\n=== CSB_PATCHER LOG. Patches applied?\n'  >> "$csb_patcher_log"

    csb_mass_patcher "$csb_patcher_log"

    if yesno "Download a ${bold}floppies${bend} collection?" "" ; then
        floppy_mass_downloader
                      printf "%25s\n" "floppies - YES"  >> "$csb_patcher_log"
    else
        printf "\n"
                      printf "%24s\n" "floppies - NO"   >> "$csb_patcher_log"
    fi

    printf '==================== Bad files found?\n'    >> "$csb_patcher_log"
    csb_finder "orig" "$csb_patcher_log" "applied correctly although at slightly different lines, can ignore it."
     csb_finder "rej" "$csb_patcher_log" "perhaps failed to apply, could result in a broken build! ${bred}Please report${bend}"

    printf '\n'                                         >> "$csb_patcher_log"
    csb_printer "$csb_patcher_log"
    csb_usage
else
    case "$1" in
        *"print"*)
            csb_patcher_log="./.csb_patcher"
            csb_printer "$csb_patcher_log"
            ;;
        *"config"*)
            csb_configurer "./.config"
            ;;
        *"atom"*|*"flop"*)
            if ! command_exists "wget" || \
               ! command_exists "unzip" || \
               ! command_exists "sha256sum" ; then
                exit 1
            fi
            cbfs_mass_adder "$1" "./build/cbfstool" "./build/coreboot.rom" "./build/coreflop.rom"
            ;;
        *"help"*|*"usage"*)
            printf "\n"
            csb_usage
            ;;
        *)
            printf "\n${bred}ERROR${bend}: unknown argument ${bold}$1${bend} !\n\n"
            csb_usage
            exit 1
            ;;
    esac
fi

exit 0

#
