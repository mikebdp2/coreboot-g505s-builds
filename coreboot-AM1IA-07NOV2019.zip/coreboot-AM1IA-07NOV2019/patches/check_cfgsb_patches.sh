#!/bin/sh
rm -f "./sha256sums_cfgsb_my.txt"
sha256sum "./4f752f0.diff" >  "./sha256sums_cfgsb_my.txt"
if cmp -s "./sha256sums_cfgsb_my.txt" "./sha256sums_cfgsb_correct.txt"
then
    echo "SHA256 checksums are correct, please run ./apply_cfgsb_patches.sh"
    exit 0
else
    echo "! MISMATCH ! See ./sha256sums_cfgsb_my.txt and ./sha256sums_cfgsb_correct.txt"
    exit 1
fi
#
