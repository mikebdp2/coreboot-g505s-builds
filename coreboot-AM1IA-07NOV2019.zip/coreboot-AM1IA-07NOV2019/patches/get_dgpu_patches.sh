#!/bin/sh
###
### https://review.coreboot.org/c/coreboot/+/31448
### src/device/pci: Add support for discrete VGA initialization and OpROM loading
###
rm -f "./05b5785.diff"
wget "https://review.coreboot.org/changes/31448/revisions/20/patch?zip"
unzip "./patch?zip" && rm -f "./patch?zip" # && patch -p1 < "./05b5785.diff"
###
### https://review.coreboot.org/c/coreboot/+/31450
### lenovo/g505s: Add the discrete VGA support for AMD Lenovo G505S laptop
###
rm -f "./a08e433.diff"
wget "https://review.coreboot.org/changes/31450/revisions/14/patch?zip"
unzip "./patch?zip" && rm -f "./patch?zip" # && patch -p1 < "./a08e433.diff"
###
