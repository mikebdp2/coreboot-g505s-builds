#!/bin/sh
###
### https://review.coreboot.org/c/coreboot/+/31448
### src/device/pci: Add support for discrete VGA initialization and OpROM loading
###
patch -p1 < "./05b5785.diff"
###
### https://review.coreboot.org/c/coreboot/+/31450
### lenovo/g505s: Add the discrete VGA support for AMD Lenovo G505S laptop
###
patch -p1 < "./a08e433.diff"
###
