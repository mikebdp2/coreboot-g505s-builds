#!/bin/sh
###
### https://review.coreboot.org/c/coreboot/+/33509
### csb_patcher.sh: gets,checks,installs the coreboot and SeaBIOS patches
###
rm -f "./csb_patcher.sh"
rm -f "./b34f324.diff" && rm -f "./patch?zip"
wget "https://review.coreboot.org/changes/33509/revisions/11/patch?zip"
unzip "./patch?zip" && rm -f "./patch?zip"
sha256sum_correct="c9be9a197d56f46e4ba1718238d5fe4b57eb48d666a6d0ce70c5fc4c0dfe2c0b  ./b34f324.diff"
sha256sum_my=$(sha256sum "./b34f324.diff")
printf "\n=== sha256sum should be\n$sha256sum_correct\n"
if [ "$sha256sum_my" = "$sha256sum_correct" ] ; then
    printf "^^^ this is correct, will extract a ./csb_patcher.sh script now...\n"
    patch -p1 < "./b34f324.diff"
    chmod +x "./csb_patcher.sh"
    printf "\nRun ./csb_patcher.sh help or ./csb_patcher.sh usage for more information.\n\n"
    exit 0
else
    printf "^^^ ! MISMATCH ! Check sha256sum manually: sha256sum ./b34f324.diff\n"
    exit 1
fi
###
